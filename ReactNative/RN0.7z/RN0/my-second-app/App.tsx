import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  Button,
  Image,
  TouchableOpacity,
  Pressable,
  FlatList,
  SectionList,
  Switch,
  ActivityIndicator,
  Modal,
  RefreshControl,
  StatusBar,
  KeyboardAvoidingView,
  SafeAreaView,
  Alert,
  Dimensions,
  Platform,
} from 'react-native';

export default function App() {
  const [text, setText] = useState('');
  const [isEnabled, setIsEnabled] = useState(false);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);

  const screenWidth = Dimensions.get('window').width;

  return (
    <SafeAreaView style={{ flex: 1 }}>
      <StatusBar barStyle="light-content" backgroundColor="#2d20df" />
      <KeyboardAvoidingView behavior="padding" style={{ flex: 1 }}>
        <ScrollView
          style={styles.scroll}
          contentContainerStyle={styles.content}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={() => {
                setRefreshing(true);
                setTimeout(() => setRefreshing(false), 1500);
              }}
            />
          }
        >
          {/* View */}
          <View style={styles.section}>
            <Text style={styles.title}>View</Text>
            <Text>Contenedor básico para estructurar layouts.</Text>
          </View>

          {/* Text */}
          <View style={styles.section}>
            <Text style={styles.title}>Text</Text>
            <Text>Componente para mostrar texto en pantalla.</Text>
          </View>

          {/* Image */}
          <View style={styles.section}>
            <Text style={styles.title}>Image</Text>
            <Image
              source={{ uri: 'https://reactnative.dev/img/tiny_logo.png' }}
              style={{ width: 50, height: 50 }}
            />
          </View>

          {/* TextInput */}
          <View style={styles.section}>
            <Text style={styles.title}>TextInput</Text>
            <TextInput
              style={styles.input}
              placeholder="Escribe algo..."
              value={text}
              onChangeText={setText}
            />
            <Text>Texto ingresado: {text}</Text>
          </View>

          {/* Button */}
          <View style={styles.section}>
            <Text style={styles.title}>Button</Text>
            <Button title="Presionar" onPress={() => Alert.alert('Botón presionado')} />
          </View>

          {/* TouchableOpacity */}
          <View style={styles.section}>
            <Text style={styles.title}>TouchableOpacity</Text>
            <TouchableOpacity
              style={styles.button}
              onPress={() => Alert.alert('TouchableOpacity presionado')}
            >
              <Text style={styles.buttonText}>Click aquí</Text>
            </TouchableOpacity>
          </View>

          {/* Pressable */}
          <View style={styles.section}>
            <Text style={styles.title}>Pressable</Text>
            <Pressable onPress={() => Alert.alert('Pressable presionado')}>
              <Text style={{ color: 'blue' }}>Tócame</Text>
            </Pressable>
          </View>

          {/* FlatList */}
          <View style={styles.section}>
            <Text style={styles.title}>FlatList</Text>
            <FlatList
              data={[{ key: 'Elemento 1' }, { key: 'Elemento 2' }]}
              renderItem={({ item }) => <Text>{item.key}</Text>}
            />
          </View>

          {/* SectionList */}
          <View style={styles.section}>
            <Text style={styles.title}>SectionList</Text>
            <SectionList
              sections={[{ title: 'Sección A', data: ['Item 1', 'Item 2'] }]}
              renderItem={({ item }) => <Text>{item}</Text>}
              renderSectionHeader={({ section }) => (
                <Text style={{ fontWeight: 'bold' }}>{section.title}</Text>
              )}
            />
          </View>

          {/* Switch */}
          <View style={styles.section}>
            <Text style={styles.title}>Switch</Text>
            <Switch
              value={isEnabled}
              onValueChange={() => setIsEnabled((prev) => !prev)}
            />
            <Text>{isEnabled ? 'Encendido' : 'Apagado'}</Text>
          </View>

          {/* ActivityIndicator */}
          <View style={styles.section}>
            <Text style={styles.title}>ActivityIndicator</Text>
            {loading ? (
              <ActivityIndicator size="large" color="blue" />
            ) : (
              <Button title="Cargar" onPress={() => setLoading(true)} />
            )}
          </View>

          {/* Modal */}
          <View style={styles.section}>
            <Text style={styles.title}>Modal</Text>
            <Button title="Abrir Modal" onPress={() => setModalVisible(true)} />
            <Modal visible={modalVisible} animationType="slide" transparent>
              <View style={styles.modalContainer}>
                <View style={styles.modalContent}>
                  <Text>Este es un modal</Text>
                  <Button title="Cerrar" onPress={() => setModalVisible(false)} />
                </View>
              </View>
            </Modal>
          </View>

          {/* Platform y Dimensions */}
          <View style={styles.section}>
            <Text style={styles.title}>Platform & Dimensions</Text>
            <Text>Plataforma: {Platform.OS}</Text>
            <Text>Ancho de pantalla: {screenWidth}px</Text>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  scroll: { flex: 1, backgroundColor: '#f4f4f4' },
  content: { padding: 20 },
  section: {
    marginBottom: 25,
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 10,
    elevation: 3,
  },
  title: { fontSize: 20, fontWeight: 'bold', marginBottom: 8, color: '#2d20df' },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 8,
    borderRadius: 5,
    marginBottom: 5,
  },
  button: {
    backgroundColor: '#2d20df',
    padding: 10,
    borderRadius: 8,
  },
  buttonText: { color: '#fff', fontWeight: 'bold', textAlign: 'center' },
  modalContainer: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  modalContent: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 10,
  },
});
