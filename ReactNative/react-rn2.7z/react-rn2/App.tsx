// App.tsx
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import LoginScreen from './screens/LoginScreen';
import WelcomeScreen from './screens/WelcomeScreen';
import ProfileScreen from './screens/ProfileScreen';

// Tipos para las rutas
export type RootTabParamList = {
  Login: undefined;
  Welcome: { user: { id: number; username: string; name?: string; email?: string } };
  Profile: { user: { id: number; username: string; name?: string; email?: string } } | undefined;
};

// Configuración del Tab Navigator
const Tab = createBottomTabNavigator<RootTabParamList>();

export default function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator initialRouteName="Login" screenOptions={{ headerShown: true }}>
        <Tab.Screen
          name="Login"
          component={LoginScreen}
          options={{ title: 'Ingreso' }}
        />
        <Tab.Screen
          name="Welcome"
          component={WelcomeScreen}
          options={{ title: 'Bienvenida' }}
        />
        <Tab.Screen
          name="Profile"
          component={ProfileScreen}
          options={{ title: 'Perfil' }}
        />
      </Tab.Navigator>
    </NavigationContainer>
  );
}
