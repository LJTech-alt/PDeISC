import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';
import type { RouteProp } from '@react-navigation/native';
import type { RootTabParamList } from '../App';

type WelcomeRouteProp = RouteProp<RootTabParamList, 'Welcome'>;

type Props = {
  route: WelcomeRouteProp;
  navigation: any;
};

export default function WelcomeScreen({ route, navigation }: Props) {
  const user = route.params?.user;

  return (
    <View style={styles.container}>
      <Text style={styles.hola}>¡Bienvenido{user?.name ? `, ${user.name}` : ''}!</Text>
      <Text style={styles.small}>Usuario: {user?.username}</Text>
      <Text style={styles.small}>Email: {user?.email ?? '—'}</Text>

      <View style={{height: 20}} />
      <Button title="Ir a mi Perfil" onPress={() => navigation.navigate('Profile', { user })} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: '#f4f6f8' },
  hola: { fontSize: 28, color: '#d9534f', fontWeight: 'bold' },
  small: { marginTop: 8, fontSize: 16 }
});
