// screens/LoginScreen.tsx
import React, { useEffect } from 'react';
import { View, Button, Text, StyleSheet, Alert } from 'react-native';
import * as WebBrowser from 'expo-web-browser';
import * as Google from 'expo-auth-session/providers/google';
import { useNavigation } from '@react-navigation/native';
import axios from 'axios';

// Necesario para cerrar el flujo de Google OAuth en Expo Go
WebBrowser.maybeCompleteAuthSession();

export default function LoginScreen() {
  const navigation = useNavigation<any>();

  // Configuración de Google OAuth (usa tu Client ID)
  const [request, response, promptAsync] = Google.useAuthRequest({
    clientId: '89955154051-l02eks7vk9tbp18l9ksrt0qauo22kp5f.apps.googleusercontent.com',
  });

  // 👉 Cambiá esta URL según cómo estés ejecutando la app:
  // - Si usás EMULADOR ANDROID → usar "http://10.0.2.2/api/login.php"
  // - Si usás CELULAR REAL → usar "http://TU_IP_LOCAL/api/login.php"
  const API_URL = 'http://10.0.11.183/api/login.php'; // <--- CAMBIA ESTO SI USAS CELULAR REAL

  // Manejo de la respuesta de Google OAuth
  useEffect(() => {
    if (response?.type === 'success') {
      const { authentication } = response;
      if (authentication?.accessToken) {
        getGoogleUserInfo(authentication.accessToken);
      }
    }
  }, [response]);

  // Obtener info del usuario desde Google y enviar al backend
  const getGoogleUserInfo = async (token: string) => {
    try {
      const res = await fetch('https://www.googleapis.com/userinfo/v2/me', {
        headers: { Authorization: `Bearer ${token}` },
      });
      const user = await res.json();

      // Enviar usuario al backend PHP (login o registro)
      const apiRes = await axios.post(API_URL, {
        username: user.email,
        password: 'google_oauth', // Contraseña genérica solo para Google
        name: user.name,
      });

      if (apiRes.data.success) {
        Alert.alert('Bienvenido', `Hola ${apiRes.data.user.name}`);
        navigation.navigate('Profile', { user: apiRes.data.user });
      } else {
        Alert.alert('Error', apiRes.data.message || 'Error al iniciar sesión');
      }
    } catch (err) {
      console.error('Error al obtener info del usuario o conectar con PHP:', err);
      Alert.alert('Error', 'No se pudo conectar con el servidor.');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Iniciar sesión con Google</Text>
      <Button
        title="Continuar con Google"
        disabled={!request}
        onPress={() => promptAsync()}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#fff' },
  title: { fontSize: 22, fontWeight: 'bold', marginBottom: 20 },
});
