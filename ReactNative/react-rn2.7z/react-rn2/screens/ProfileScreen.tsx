import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  Button,
  Image,
  TextInput,
  StyleSheet,
  Alert,
  ScrollView,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as Location from 'expo-location';
import * as DocumentPicker from 'expo-document-picker';
import type { RouteProp } from '@react-navigation/native';
import type { RootTabParamList } from '../App';

type ProfileRouteProp = RouteProp<RootTabParamList, 'Profile'>;

type Props = {
  route: ProfileRouteProp;
};

export default function ProfileScreen({ route }: Props) {
  const user = route.params?.user;
  const [name, setName] = useState(user?.name ?? '');
  const [phone, setPhone] = useState('');
  const [imageUri, setImageUri] = useState<string | null>(null);
  const [location, setLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [docInfo, setDocInfo] = useState<{ name: string; size: number } | null>(null);

  // Permiso de acceso a galería
  useEffect(() => {
    (async () => {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permiso denegado', 'Necesitamos permiso para acceder a las fotos.');
      }
    })();
  }, []);

  // Elegir imagen
  const pickImage = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 0.7,
    });

    if (!result.canceled && result.assets && result.assets.length > 0) {
      setImageUri(result.assets[0].uri);
    }
  };

  // Obtener ubicación
  const getLocation = async () => {
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permiso denegado', 'No se otorgó permiso de ubicación.');
      return;
    }
    const loc = await Location.getCurrentPositionAsync({});
    setLocation(loc.coords);
  };

  // Elegir documento
  const pickDocument = async () => {
    const res = await DocumentPicker.getDocumentAsync({});
    if (res.assets && res.assets.length > 0) {
      const file = res.assets[0];
      setDocInfo({ name: file.name, size: file.size ?? 0 });
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Perfil de usuario</Text>
      <Text style={{ marginBottom: 6 }}>Usuario: {user?.username}</Text>

      <Image
        source={
          imageUri
            ? { uri: imageUri }
            : { uri: 'https://via.placeholder.com/120' }
        }
        style={styles.avatar}
      />

      <Button title="Seleccionar foto" onPress={pickImage} />

      <Text style={{ marginTop: 12 }}>Nombre</Text>
      <TextInput style={styles.input} value={name} onChangeText={setName} />

      <Text>Teléfono</Text>
      <TextInput
        style={styles.input}
        value={phone}
        onChangeText={setPhone}
        keyboardType="phone-pad"
      />

      <View style={{ height: 10 }} />
      <Button title="Obtener ubicación actual" onPress={getLocation} />
      {location && (
        <Text>
          Lat: {location.latitude.toFixed(5)}, Lon: {location.longitude.toFixed(5)}
        </Text>
      )}

      <View style={{ height: 10 }} />
      <Button
        title="Subir/Seleccionar Documento (DNI, etc.)"
        onPress={pickDocument}
      />
      {docInfo && (
        <Text>
          Archivo: {docInfo.name} ({docInfo.size} bytes)
        </Text>
      )}

      <View style={{ height: 20 }} />
      <Button
        title="Guardar cambios (local)"
        onPress={() => Alert.alert('Guardado', 'Perfil actualizado (demo)')}
      />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { padding: 20, alignItems: 'center' },
  title: { fontSize: 22, marginBottom: 10 },
  avatar: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: '#ddd',
    marginBottom: 8,
  },
  input: {
    width: '100%',
    padding: 8,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 6,
    marginBottom: 8,
  },
});
