document.addEventListener("DOMContentLoaded", () => {
  const formulario = document.getElementById("formulario");
  const salida = document.getElementById("salida");

  formulario.addEventListener("submit", (e) => {
    e.preventDefault();
    const datos = new FormData(formulario);
    let resultado = "<h3>Datos del formulario:</h3><ul>";
    for (const [clave, valor] of datos.entries()) {
      resultado += `<li><strong>${clave}</strong>: ${valor}</li>`;
    }
    resultado += "</ul>";
    salida.innerHTML = resultado;
  });
});