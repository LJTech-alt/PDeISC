document.addEventListener("DOMContentLoaded", () => {
    const secciones = document.querySelectorAll(".seccion");

    const eventos = ["mouseenter", "mouseleave", "click", "dblclick", "contextmenu"];

    document.querySelectorAll(".btn-nav").forEach((btn, index) => {
        const evento = eventos[index % eventos.length];
        btn.addEventListener(evento, (e) => {
            e.preventDefault();
            secciones.forEach(sec => sec.style.display = "none");
            const objetivo = document.getElementById(btn.dataset.target);
            if (objetivo) objetivo.style.display = "block";
        });
    });
});