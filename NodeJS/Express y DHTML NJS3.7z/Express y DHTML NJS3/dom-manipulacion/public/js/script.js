document.addEventListener("DOMContentLoaded", () => {
    const contenedor = document.getElementById("contenedor");

    document.getElementById("agregarH1").onclick = () => {
        if(!document.getElementById("titulo")){
            const h1 = document.createElement("h1");
            h1.id = "titulo";
            h1.textContent = "Hola DOM";
            contenedor.appendChild(h1);
        }
    };

    document.getElementById("cambiarTexto").onclick = () => {
        const h1 = document.getElementById("titulo");
        if (h1) h1.textContent = "Chau DOM";
    };

     document.getElementById("cambiarColor").onclick = () => {
        const h1 = document.getElementById("titulo");
        if (h1) h1.style.color = "red";
    };

    document.getElementById("agregarImagen").onclick = () => {
        if (!document.getElementById("imagen")) {
            const img = document.createElement("img");
            img.id ="imagen";
            img.src = "/img/Visual_Studio_Icon_2022.png";
            contenedor.appendChild(img);
        }
    };

    document.getElementById("cambiarImagen").onclick = () => {
        const img = document.getElementById("imagen");
        if (img) img.src = "/img/Visual_Studio_Icon_2024.png";
    };

    document.getElementById("cambiarTamaño").onclick = () => {
        const img = document.getElementById("imagen");
        if (img) {
            img.style.width = "300px";
            img.style.width = "auto";
        } 
    };
});