document.addEventListener("DOMContentLoaded", () => {
  const salida = document.getElementById("contenido");

  document.getElementById("agregarParrafo").addEventListener("click", () => {
    salida.innerHTML += "<p>Este es un párrafo añadido dinámicamente.</p>";
  });

  document.getElementById("agregarLista").addEventListener("click", () => {
    salida.innerHTML += `<ul><li>Elemento 1</li><li>Elemento 2</li></ul>`;
  });

  document.getElementById("agregarImagen").addEventListener("click", () => {
    salida.innerHTML += `<img src='/img/Visual_Studio_Icon_2022.png' alt='Imagen' style='max-width:200px;' />`;
  });
});