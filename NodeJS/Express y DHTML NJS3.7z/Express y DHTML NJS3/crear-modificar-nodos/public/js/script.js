document.addEventListener("DOMContentLoaded", () => {
    const contenedor = document.getElementById("enlaces");
    const resultado = document.getElementById("resultado");

    document.getElementById("crearEnlaces").addEventListener("click", () => {
        contenedor.innerHTML = "";
        const urls = [
            {texto: "Google", href: "https://www.google.com"},
            {texto: "GitHub", href: "https://www.github.com"},
            {texto: "Wikipedia", href: "https://www.wikipedia.org"},
            {texto: "MDN", href: "https://developer.mozilla.org"},
            {texto: "StackOverflow", href: "https://stackoverflow.com"}
        ];

        urls.forEach((item, i) => {
            const a = document.createElement("a");
            a.href = item.href;
            a.textContent = item.texto;
            a.target = "_blank";
            a.dataset.index = i;
            contenedor.appendChild(a);
        });
    });

    document.getElementById("modificarEnlaces").addEventListener("click", () => {
        const enlaces = contenedor.querySelectorAll("a");
        enlaces.forEach((a, i) => {
            a.href = `https://example.com/enlace-${i + 1}`;
            a.textContent = `Nuevo Enlace ${i + 1}`;
            resultado.innerHTML += `Modificado: ${a.outerHTML}<br/>`;
        });
    });
});