document.addEventListener("DOMContentLoaded", () => {
    const secciones = document.querySelectorAll(".seccion");
    const resultado = document.getElementById("resultado");

    secciones.forEach(sec => {
        sec.addEventListener("click", () => {
            const cantidad = sec.children.length;
            resultado.textContent = `Seccion '${sec.id}' tiene ${cantidad} hijo(s)`;
        });
    });
});