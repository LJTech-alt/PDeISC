//Programa para eliminar el ultimo animal
let animales = ["Perro", "Gato", "Conejo"];
animales.pop();
console.log("Animales: ", animales);

//Programa para quitar el ultimo producto
let compras = ["Pan", "Leche", "Huevos"];
let eliminado = compras.pop();
console.log("Producto eliminado: ", eliminado);
console.log("Lista: ", compras);

//Programa para vaciar un array con while + pop
let numeros = [1,2,3,4];
while (numeros.length > 0) {
    numeros.pop();
}
console.log("Array vacio: ", numeros);