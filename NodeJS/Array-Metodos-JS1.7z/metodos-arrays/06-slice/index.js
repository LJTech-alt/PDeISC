//Programa para copiar los primeros 3 numeros
let numeros = [10, 20, 30, 40, 50];
let primeros = numeros.slice(0, 3);
console.log("Primeros 3:", primeros);

//Programa que copia peliculas desde la posicion 2 hasta 4
let peliculas = ["Titanic", "Matrix", "Shrek", "Avatar", "Dune"];
let selection = peliculas.slice(2, 5);
console.log("Peliculas: ", selection);

//Programa para crear un array nuevo de los ultimos 3 elementos
let ultimos = numeros.slice(-3);
console.log("Ultimos 3: ", ultimos);