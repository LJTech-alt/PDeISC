//Programa para quitar el primer numero
let enteros = [100, 200, 300];
enteros.shift();
console.log("Enteros: ", enteros);

//Programa para eliminar el primer mensaje
let mensajes = ["Hola", "¿Estas?", "Nos vemos"];
mensajes.shift();
console.log("Mensajes: ", mensajes);

//Programa de cola de atención
let cola = ["Cliente 1", "Cliente 2", "Cliente 3"];
while (cola.length > 0) {
    let atendido = cola.shift();
    console.log("Atendiendo a: ", atendido);
}