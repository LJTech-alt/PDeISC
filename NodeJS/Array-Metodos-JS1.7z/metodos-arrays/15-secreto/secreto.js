const fs = require('fs');

//Leer el contenido del archivo SECRETO.IN
const inputPath = './SECRETO.IN';
const outPath = './SECRETO.OUT';

try {
    const data = fs.readFileSync(inputPath, 'utf8');

    //Reemplazar los textos entre parentesis invirtiendolos
    const decoded = data.replace(/\(([^()]+)\)/g, (_, textoEnParentesis) => {
        return textoEnParentesis.split('').reverse().join('');
    });

    //Guardar el mensaje decodificado
    fs.writeFileSync(outPath, decoded, 'utf8');

    console.log('Mensaje decodificado correctamente en SECRETO.OUT');
} catch (error) {
    console.error('Error al procesar el archivo:', error.message);
}