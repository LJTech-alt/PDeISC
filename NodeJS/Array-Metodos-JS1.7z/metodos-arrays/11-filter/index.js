//Programa para filtrar los numeros mayores a 10
let nums = [5, 15, 20, 7];
let mayores = nums.filter(n => n > 10);
console.log(mayores);

//Programa que usa palabras largas
let palabra = ["sol", "montaña", "cielo", "estrella"];
let largas = palabra.filter(p => p.length > 5);
console.log(largas);

//Programa que muestra usuarios activos
let usuarios = [
    { nombre: "Lau", activo: true },
    { nombre: "Juana", activo: false }
];
let activos = usuarios.filter(u => u.activo);
console.log(activos);