//Programa para encontrar la posicion de perro
let palabras = ["gato", "perro", "pez"];
console.log("indice de perro: ", palabras.indexOf("perro"));

//Programa para verificar un numero
let valores = [10, 20, 50, 100];
let posicion = valores.indexOf(50);
console.log("Posicion de 50: ", posicion);

//Programa para buscar una ciudad
let ciudades = ["Roma", "Londres, ", "Madrid"];
let idx = ciudades.indexOf("Madrid");
if (idx !== -1) {
    console.log("Madrid esta en la posicion:", idx)
} else {
    console.log("Madrid no esta en el array.");
}