//Programa que elimina dos letras desde la posicion 1
let letras = ["A", "B", "C", "D"];
letras.splice(1, 2);
console.log("Letras: ", letras);

//Programa para insertar un nombre en la segunda posicion
let nombres = ["Juan", "Lucas", "Pedro"];
nombres.splice(1, 0, "Martina");
console.log("Nombres: ", nombres);

//Programa para reemplazar dos elementos
let paises = ["Argentina", "Chile", "Perú", "Brasil"];
paises.splice(1, 2, "Uruguay", "Paraguay");
console.log("Paises: ", paises);