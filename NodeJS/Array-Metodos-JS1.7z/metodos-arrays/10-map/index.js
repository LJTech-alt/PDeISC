//Programa para multiplicar por 3
let nums = [1, 2, 3];
let triple = nums.map(n => n * 3);
console.log(triple);

//Programa para poner mayusculas
let nombres = ["juan", "maria", "pedro"];
let mayus = nombres.map(n => n.toUpperCase());
console.log(mayus);

//Programa para agregar 21% IVA
let precios = [100, 200, 300];
let conIVA = precios.map(p => p * 1.21);
console.log(conIVA);