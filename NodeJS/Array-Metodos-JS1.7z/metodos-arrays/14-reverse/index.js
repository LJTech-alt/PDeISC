//Programa para invertir letras
let letras = ["a", "b", "c"];
letras.reverse();
console.log(letras);

//Programa para invertir los numeros
let nums = [1, 2, 3, 4];
nums.reverse();
console.log(nums);

//Programa para invertir string
let texto = "Hola mundo";
let invertido = texto.split("").reverse().join("");
console.log(invertido);