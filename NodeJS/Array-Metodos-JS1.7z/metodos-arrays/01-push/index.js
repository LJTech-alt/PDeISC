//Programa para agregar frutas con push()
let frutas = [];
frutas.push("Manzana");
frutas.push("Banana");
frutas.push("Naranja");
console.log("Frutas: ", frutas);

//Programa para agregar amigos
let amigos = ["Carlos", "Lucia"];
amigos.push("Mariano", "Sofia", "Pedro");
console.log("Amigos: ", amigos);

//Programa para agregar un numero solo si es mayor que el ultimo
let numeros = [5, 12, 30];
let nuevoNumero = 35;
if (nuevoNumero > numeros[numeros.length - 1]){
    numeros.push(nuevoNumero);
}
console.log("Numeros: ", numeros);