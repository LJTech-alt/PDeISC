//Programa para verificar si contiene admin
let roles = ["user", "editor", "admin"];
console.log("Contiene admin:", roles.includes("admin"));

//Programa para verificar si esta verde
let colores = ["azul", "rojo", "verde"];
console.log("¿Esta verde?", colores.includes("verde"));

//Programa que verifica antes de agregar
let lista = [1, 2, 3];
let numero = 4;
if(!lista.includes(numero)) {
    lista.push(numero);
}
console.log("Lista actualizada", lista);