//Programa para sumar elementos
let numeros = [1, 2, 3, 4];
let suma = numeros.reduce((acc, n) => acc + n, 0);
console.log("Suma:", suma);

//Programa para multiplicar elementos
let mult = numeros.reduce((acc, n) => acc * n, 1);
console.log("Multiplicacion:", mult);

//Programa que muestra el precio total
let items = [
    { precio: 10},
    { precio: 20},
    { precio: 30}
];
let total = items.reduce((acc, obj) => acc + obj.precio, 0);
console.log("Total:", total);