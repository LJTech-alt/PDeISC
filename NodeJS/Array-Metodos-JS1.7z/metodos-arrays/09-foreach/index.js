//Programa que saluda los nombres
let nombres = ["Ana", "Luis", "Maria"];
nombres.forEach(nombre => {
    console.log(`Hola, ${nombre}!`);
});

//Programa que da el doble de cada numero
let nums = [2, 4, 6,];
nums.forEach(num => {
    console.log(num * 2);
});

//Programa que muestra personas
let personas =[
    { nombre: "Lucas", edad: 20 },
    { nombre: "Marta", edad: 25 }
];
personas.forEach(p => {
    console.log(`${p.nombre} tiene ${p.edad} años.`);
});