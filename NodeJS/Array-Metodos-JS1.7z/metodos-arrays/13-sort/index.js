//Programa de numeros de menor a mayor
let numeros = [30, 10, 20];
numeros.sort((a, b) => a - b);
console.log(numeros);

//Programas de palabras alfabeticamente
let palabras = ["Banana", "manzana", "pera"];
palabras.sort();
console.log(palabras);

//Programa de objetos por edad
let personas = [
    { nombre: "Ana", edad: 30 },
    { nombre: "Luis", edad: 25 }
];
personas.sort((a, b) => a.edad -b.edad);
console.log(personas);