//Programa para agregar colores al principio
let colores = [];
colores.unshift("Rojo");
colores.unshift("Verde");
colores.unshift("Azul");
console.log("Colores: ", colores);

//Programa para mostrar una tarea urgente al principio
let tareas = ["Lavar los platos", "Hacer tarea"];
tareas.unshift("¡Pagar impuestos!");
console.log("Tareas: ", tareas);

//Programa para mostrar el usuario al principio
let conectados = ["user123", "lolo98"];
conectados.unshift("nuevoUsuario");
console.log("Usuarios conectados: ", conectados);
