console.log("Suma: " + (4 + 5));
console.log("Resta: " + (3 - 6));
console.log("Multiplicacion: " + (2 * 7));
console.log("Division: " + (20 / 4));