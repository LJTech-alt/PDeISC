const calculos = require("./calculos");

console.log("Suma: " + calculos.suma(5, 3));
console.log("Resta: " + calculos.resta(8, 6));
console.log("Multiplicacion: " + calculos.multiplicacion(3, 11));
console.log("Division: " + calculos.division(30, 5));