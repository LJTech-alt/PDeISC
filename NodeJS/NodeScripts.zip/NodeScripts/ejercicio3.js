function suma(a, b){
    return a + b;
}

function resta(a, b){
    return a - b;
}

function multiplicacion (a, b){
    return a * b;
}

function division (a, b){
    return a / b;
}

console.log("Suma: " + suma(4, 5));
console.log("Resta: " + resta(3, 6));
console.log("Multiplicacion: " + multiplicacion(2, 7));
console.log("Division: " + division(20, 4));