console.log("Hola mundo desde Node.js");
console.log("Fin");