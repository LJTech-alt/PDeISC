document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('productoForm');
    const resultado = document.getElementById('resultado');
  
    form.addEventListener('submit', (e) => {
      e.preventDefault();
  
      const formData = new FormData(form);
      const datos = Object.fromEntries(formData.entries());
  
      resultado.innerHTML = `
        <h3>Producto ingresado:</h3>
        <ul>
          <li><strong>Deporte:</strong> ${datos.deporte}</li>
          <li><strong>Herramienta:</strong> ${datos.herramienta}</li>
          <li><strong>Precio:</strong> $${datos.precio}</li>
          <li><strong>Marca:</strong> ${datos.marca}</li>
        </ul>
      `;
  
      form.reset();
    });
  });
  