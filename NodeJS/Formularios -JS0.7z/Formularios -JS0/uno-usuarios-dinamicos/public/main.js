document.addEventListener('DOMContentLoaded', () => {
    const listaUsuarios = document.getElementById('listaUsuarios');
    const form = document.getElementById('formUsuario');
    const mensaje = document.getElementById('mensaje');
  
    // Cargar usuarios existentes
    fetch('/api/usuarios')
      .then(res => res.json())
      .then(data => {
        data.forEach(usuario => agregarUsuarioDOM(usuario));
      });
  
    // Agregar usuario nuevo
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const formData = new FormData(form);
      const datos = Object.fromEntries(formData.entries());
  
      const res = await fetch('/api/usuarios', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(datos)
      });
  
      const resultado = await res.json();
  
      if (resultado.exito) {
        agregarUsuarioDOM(resultado.usuario);
        mensaje.textContent = '✅ Usuario agregado correctamente';
        mensaje.style.color = 'green';
        form.reset();
      } else {
        mensaje.textContent = '❌ Error al agregar usuario';
        mensaje.style.color = 'red';
      }
    });
  
    function agregarUsuarioDOM(usuario) {
      const li = document.createElement('li');
      li.textContent = `${usuario.nombre} ${usuario.apellido}`;
      listaUsuarios.appendChild(li);
    }
  });
  