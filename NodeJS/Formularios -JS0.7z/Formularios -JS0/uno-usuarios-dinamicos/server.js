const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3001;

app.use(express.json());
app.use(express.static('public'));
app.set('view engine', 'ejs');

// Ruta principal
app.get('/', (req, res) => {
  res.render('index');
});

// Obtener usuarios
app.get('/api/usuarios', (req, res) => {
  const usuarios = JSON.parse(fs.readFileSync('./data/usuarios.json'));
  res.json(usuarios);
});

// Agregar usuario
app.post('/api/usuarios', (req, res) => {
  const usuario = req.body;
  try {
    const usuarios = JSON.parse(fs.readFileSync('./data/usuarios.json'));
    usuarios.push(usuario);
    fs.writeFileSync('./data/usuarios.json', JSON.stringify(usuarios, null, 2));
    res.json({ exito: true, usuario });
  } catch (error) {
    res.status(500).json({ exito: false });
  }
});

app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
