document.getElementById('personaForm').addEventListener('submit', async (e) => {
    e.preventDefault();

    const form = e.target;
    const datos = Object.fromEntries(new FormData(form));

    const res = await fetch('/guardar', {
        method: 'POST',
        headers:{ 'Content-Type': 'application/json'},
        body: JSON.stringify(datos)
    });

    const resultado = await res.json();
    const mensaje = document.getElementById('mensaje');

    if (resultado.exito) {
        mensaje.textContent = 'Datos guardados correctamente.';
        mensaje.style.color = 'green';
        form.reset();
    } else {
        mensaje.textContent = 'Error al guardar los datos';
        mensaje.style.color = 'red';
    }
});