const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require ('path');

const app = express();
const PORT = 3000;

app.use(bodyParser.urlencoded({ extended: true}));
app.use(express.json());
app.use(express.static('public'));
app.set('view engine', 'ejs');

// La pagina principal
app.get('/', (req, res) => {
    res.render('index');
});

// Ver los usuarios almacenados
app.get('/usuarios', (req, res) => {
    const personas = JSON.parse(fs.readFileSync('./data/personas.json'));
    res.render('usuarios', { personas });
});

//Guardar nueva persona
app.post('/guardar', (req, res) => {
    const nuevaPersona = req.body;
    try {
        const personas = JSON.parse(fs.readFileSync('./data/personas.json'));
        personas.push(nuevaPersona);
        fs.writeFileSync('./data/personas.json', JSON.stringify(personas, null, 2));
        res.json({ exito: true});
    } catch (error) {
        res.status(500).json({ exito: false});
    }
});

app.listen(PORT, () => {
    console.log(`Servidor en http://localhost:${PORT}`);
});