const express = require("express");
const path = require("path");
const app = express();

// Middleware para servir archivos estáticos
app.use(express.static(path.join(__dirname, "public")));

// API de ejemplo
app.get("/api/alumnos", (req, res) => {
  const alumnos = [
    { nombre: "Lautaro Juárez", email: "lautaro@example.com", edad: 18 },
    { nombre: "Valentina López", email: "valen@example.com", edad: 19 },
    { nombre: "Santiago Pérez", email: "santi@example.com", edad: 20 },
    { nombre: "Martina Gómez", email: "martina@example.com", edad: 21 }
  ];
  res.json(alumnos);
});

// Página principal
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

// Iniciar servidor
app.listen(3000, () => {
  console.log("Proyecto 4 corriendo en http://localhost:3000");
});
