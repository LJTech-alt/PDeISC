document.addEventListener("DOMContentLoaded", async () => {
  const lista = document.getElementById("listaAlumnos");

  try {
    const res = await fetch("/api/alumnos");
    const alumnos = await res.json();

    alumnos.forEach(alumno => {
      const li = document.createElement("li");
      li.textContent = `${alumno.nombre} (${alumno.email}) - Edad: ${alumno.edad}`;
      lista.appendChild(li);
    });
  } catch (error) {
    console.error("Error al cargar alumnos:", error);
  }
});
