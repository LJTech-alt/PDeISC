document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("form-usuario");
    const respuestaDiv = document.getElementById("respuesta");

    form.addEventListener("submit", async (e) => {
        e.preventDefault();

        const nombre = document.getElementById("nombre").value;
        const email = document.getElementById("email").value;

        try {
            const res = await axios.post("https://jsonplaceholder.typicode.com/users", {
                name: nombre,
                email: email
            });

            respuestaDiv.innerHTML = `<p class="success">Usuario registrado con ID: <strong>${res.data.id}</strong></p>`;
        } catch (error) {
            console.error("Error al enviar datos:", error);
            respuestaDiv.innerHTML = `<p class="error">Ocurrio un error al registrar.</p>`;
        }
    });
});